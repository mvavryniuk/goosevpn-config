#!/bin/bash
echo "======================================================= Install VPN software, if running ======================================================="
apt-get update > /dev/null 2>&1
sudo apt install strongswan strongswan-pki libcharon-extra-plugins libcharon-extauth-plugins libstrongswan-extra-plugins curl net-tools resolvconf -y > /dev/null 2>&1
echo "DNSSEC=no" >>  /etc/systemd/resolved.conf
sudo systemctl restart systemd-resolved.service
echo "========================================================= Stop VPN service, if running ========================================================="
ipsec stop
echo ""

echo "========================================================= Get IP before VPN setup =============================================================="
curl ipinfo.io
echo ""
echo "================================================================================================================================================" 

echo 'config setup'			> /etc/ipsec.conf
echo 'conn %default'			>> /etc/ipsec.conf
echo '	ikelifetime=60m'		>> /etc/ipsec.conf
echo '	keylife=20m'			>> /etc/ipsec.conf
echo '	rekeymargin=3m'			>> /etc/ipsec.conf
echo '	keyingtries=1'			>> /etc/ipsec.conf
echo '	keyexchange=ikev2'		>> /etc/ipsec.conf
echo ''					>> /etc/ipsec.conf
echo 'conn '$1				>> /etc/ipsec.conf
echo '	right='$1			>> /etc/ipsec.conf
echo '	rightid=@goosevpn.com' 		>> /etc/ipsec.conf
echo '	rightsubnet=0.0.0.0/0' 		>> /etc/ipsec.conf
echo '	rightauth=pubkey' 		>> /etc/ipsec.conf
echo '	leftsourceip='`ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1'`	 	>> /etc/ipsec.conf
echo '	leftfirewall=yes' 		>> /etc/ipsec.conf
echo '	eap_identity='$2 		>> /etc/ipsec.conf
echo '	leftauth=eap' 			>> /etc/ipsec.conf
echo '	auto=start' 			>> /etc/ipsec.conf

rm -fr /etc/ipsec.d/cacerts/comodorsa.crt
rm -fr /etc/ipsec.d/comodorsadomain.crt

cp -f comodorsa.crt /etc/ipsec.d/cacerts/comodorsa.crt
cp -f comodorsadomain.crt /etc/ipsec.d/cacerts/comodorsadomain.crt 
cp -f sectigo.crt /etc/ipsec.d/cacerts/sectigo.crt
cp -f usertrust.crt /etc/ipsec.d/cacerts/usertrust.crt

echo $2" : EAP \"$3\"" 			> /etc/ipsec.secrets

echo "========================================================= Start VPN service ===================================================================="
ipsec start
sleep 10
echo ""

echo "========================================================= Get IP after VPN setup ==============================================================="
curl ipinfo.io
echo ""
echo "================================================================================================================================================"
